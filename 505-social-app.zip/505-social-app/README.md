# 505

A working social-network MVP designed as a more human, Gen-Z-native alternative to conventional microblogging.

## Core product idea

505 keeps the immediacy of Twitter/X but shifts the experience away from follower-count performance:

- Main feed with "For you" and chronological "Latest"
- Rich 500-character posts
- Four expressive reactions instead of one generic like
- Topic Rooms that behave like public group conversations
- Profiles and follower/following counts
- Bookmarks
- Notifications
- Search across people, posts, and rooms
- Media posts by URL
- Responsive desktop + mobile design
- Persistent local JSON data
- Working create / react / save / delete APIs

## Run locally

```bash
npm install
npm run dev
```

Then open:

```text
http://localhost:3000
```

The app creates `505-data.json` automatically on first launch.

## Product direction

This repository is intentionally an MVP rather than pretending to be production-ready.

A serious V2 should add:

1. Real authentication (email, phone, passkeys, social login)
2. PostgreSQL and object storage
3. Real image/video uploads
4. Replies, quote-posts, DMs, and group chats
5. A graph-based recommendation system with a user-controlled algorithm
6. Trust/safety tooling and moderation queues
7. Private accounts, blocking, muting, reporting, content controls
8. Ephemeral "Now" posts / stories
9. Audio rooms and collaborative playlists
10. Push notifications
11. Creator analytics that de-emphasize vanity metrics
12. Rate limiting, abuse prevention, observability, and backups
13. Native iOS/Android clients or a React Native app

## The differentiator

The strongest version of 505 should not compete by adding more addiction loops. It should compete by making social media feel more like actually being social:

- "Vibes" / current status instead of polished bios only
- Rooms for context-rich communities
- Reactions that communicate emotion
- Optional public counts
- A true chronological feed always available
- User-tunable recommendation controls
- Stronger separation between friends, interests, and viral content
- Smaller-context modes that encourage conversation rather than broadcasting
